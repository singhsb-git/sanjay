package com.sanlabs.openbankapi.model;

import java.util.List;

public class Transactions {
	List<OpenBankResponse> transactions;

	public List<OpenBankResponse> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<OpenBankResponse> transactions) {
		this.transactions = transactions;
	}
	

}
