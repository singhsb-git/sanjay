package com.sanlabs.openbankapi.adapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sanlabs.openbankapi.model.OpenBankResponse;
import com.sanlabs.openbankapi.model.SanlabsTransactions;

public class OpenBankApiClientImpl implements OpenBankApiClient{
	private final String baseUrl = "https://apisandbox.openbankproject.com/obp/v1.2.1"; 
	private String transactionListUrl = "/banks/bankId/accounts/accountId/viewId/transactions";
	private ObjectMapper objMaper = new ObjectMapper();
	
	public List<OpenBankResponse> getTransactionList(String bankId,	String accountId, String viewId){
		List<OpenBankResponse> opResponses = null;
		String output = null;
		String relUrl = transactionListUrl.replaceAll("bankId", bankId)
				.replaceAll("accountId", accountId)
				.replaceAll("viewId", viewId);
		try {
			URL url = new URL(baseUrl+relUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

			output = br.readLine();
			opResponses = (List<OpenBankResponse>) objMaper.readValue(output, SanlabsTransactions.class);
			conn.disconnect();

		  } catch (MalformedURLException e) {
			e.printStackTrace();
		  } catch (IOException e) {
			e.printStackTrace();
		  }
		
		return opResponses;
		
	}
	
	

}
