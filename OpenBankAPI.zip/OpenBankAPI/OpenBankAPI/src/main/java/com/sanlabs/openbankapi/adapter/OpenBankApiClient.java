package com.sanlabs.openbankapi.adapter;

import java.util.List;

import com.sanlabs.openbankapi.model.OpenBankResponse;

public interface OpenBankApiClient {
	public List<OpenBankResponse> getTransactionList(String bankId,	String accountId, String viewId);

}
