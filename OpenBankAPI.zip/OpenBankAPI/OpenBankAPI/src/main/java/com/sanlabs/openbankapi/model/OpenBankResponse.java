package com.sanlabs.openbankapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenBankResponse {
	private String id;
	private This_account this_account;
	private Other_account other_account;
	private Details details;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public This_account getThis_account() {
		return this_account;
	}

	public void setThis_account(This_account this_account) {
		this.this_account = this_account;
	}

	public Other_account getOther_account() {
		return other_account;
	}

	public void setOther_account(Other_account other_account) {
		this.other_account = other_account;
	}

	public Details getDetails() {
		return details;
	}

	public void setDetails(Details details) {
		this.details = details;
	}
	
	private class This_account{
		private String id;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}
	}
	
	private class Other_account{
		private String number;
		
		private class Holder {
			private String name;
			
		}
		
		private  class Metadata{
			private String image_URL;
		}

		public String getNumber() {
			return number;
		}

		public void setNumber(String number) {
			this.number = number;
		}
	}
	
	private class Details{
		private String type;
		private String description;
		
		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}
		
		private class Value{
			private String amount;
			private String currency;
			public String getAmount() {
				return amount;
			}
			public void setAmount(String amount) {
				this.amount = amount;
			}
			public String getCurrency() {
				return currency;
			}
			public void setCurrency(String currency) {
				this.currency = currency;
			}
		}
		
	}

}
