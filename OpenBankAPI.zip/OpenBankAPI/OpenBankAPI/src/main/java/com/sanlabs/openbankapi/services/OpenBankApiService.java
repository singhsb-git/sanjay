package com.sanlabs.openbankapi.services;

import org.springframework.stereotype.Service;

@Service
public class OpenBankApiService {
	
	

}
