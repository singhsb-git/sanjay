package com.sanlabs.openbankapi.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

@RestController
@Api("SanlabsRESTController")
@RequestMapping("/banks")
public class OpenBankApiController {
	@GetMapping("/{bankId}/accounts/{accountId}/{viewId}/transactions")
	public String getTransactionsList(@PathVariable("bankId") String player,
			@PathVariable("accountId") String accountId,
			@PathVariable("viewId") String viewId) {
	 
	        String msg = new String( "Hello " + accountId);
	        return msg;
	}

}