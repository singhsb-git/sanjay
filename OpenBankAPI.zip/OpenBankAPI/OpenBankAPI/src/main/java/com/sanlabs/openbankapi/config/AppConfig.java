package com.sanlabs.openbankapi.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.sanlabs.openbankapi")
public class AppConfig {

}
