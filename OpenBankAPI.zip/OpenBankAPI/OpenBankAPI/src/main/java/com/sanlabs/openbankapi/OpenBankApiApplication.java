package com.sanlabs.openbankapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenBankApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenBankApiApplication.class, args);
	}

}
