package com.sanlabs.openbankapi.model;

import java.util.List;

public class SanlabsTransactions {
	List<SanlabsResponse> transactions;

}
